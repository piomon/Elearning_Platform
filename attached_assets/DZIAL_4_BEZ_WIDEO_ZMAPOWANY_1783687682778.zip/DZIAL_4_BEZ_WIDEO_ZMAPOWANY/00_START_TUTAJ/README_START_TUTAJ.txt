DZIAŁ 4 - PAKIET BEZ WIDEO, DOKŁADNIE ZMAPOWANY
Data przygotowania: 10.07.2026

CO JEST W PACZCE
- 0 plików MKV,
- 16 logicznych referencji VIDEO: 11 widocznych pozycji + 5 aliasów ROOT,
- 2 quizy TXT z łącznie 9 pytaniami,
- 6 obrazów PNG z zadaniami,
- dokument DOCX z pełną treścią, obrazami i powiązaniami,
- mapy CSV, JSON i TXT,
- kompletny prompt dla agenta,
- sumy SHA-256 do identyfikacji filmów i kontroli plików w paczce.

NAJWAŻNIEJSZE
1. Filmy nie są zawarte w tym ZIP-ie. Muszą być przekazane osobno lub już istnieć na stronie.
2. Nie wolno zmieniać nazw, numerów LXX/YY ani usuwać luk w numeracji.
3. Plik/rekord ROOT jest logicznym przypisaniem filmu pozycji 01 i nie jest dodatkową pozycją dla ucznia.
4. Każdy quiz i każdy PNG ma wskazany film poprzedzający w pliku:
   01_MAPA_FILMOW/MAPOWANIE_QUIZOW_I_PNG_DO_FILMOW.csv
5. Pełna docelowa kolejność jest w:
   01_MAPA_FILMOW/KOLEJNOSC_WSZYSTKICH_MATERIALOW.csv
6. Filmy można zweryfikować po pełnej nazwie, czasie i SHA-256 w:
   01_MAPA_FILMOW/MAPA_FILMOW_DZIAL_4.csv

OD CZEGO ZACZĄĆ
1. Otwórz 00_START_TUTAJ/PROMPT_DLA_AGENTA_DZIAL_4_BEZ_WIDEO.txt.
2. Przekaż agentowi osobny folder z filmami albo dostęp do istniejącego magazynu filmów.
3. Agent ma dopasować filmy do mapy, a następnie dodać quizy i PNG dokładnie w oznaczonych pozycjach.
4. Po wdrożeniu agent ma zwrócić raport z ID/URL każdego rekordu i wynikami testów.
